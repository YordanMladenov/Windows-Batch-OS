Hello, im Windows Batch OS Version 1.0. I might get an update if the owner adds it.

Made by YordanMladenov. Copyright (C) WinExpirimenter. All rights reserved.

The license is the Microsoft License.
